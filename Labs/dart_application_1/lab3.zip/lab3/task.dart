class Task {
  String name;
  String description;
  bool isCompleted;
  
  Task(this.name, this.description, this.isCompleted);
}